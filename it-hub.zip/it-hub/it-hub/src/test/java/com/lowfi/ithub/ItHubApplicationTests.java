package com.lowfi.ithub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItHubApplicationTests {

    @Test
    void contextLoads() {
    }

}
