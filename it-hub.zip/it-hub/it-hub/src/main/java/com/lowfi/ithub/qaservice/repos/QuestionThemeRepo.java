package com.lowfi.ithub.qaservice.repos;

import com.lowfi.ithub.qaservice.models.QuestionTheme;
import org.springframework.data.repository.CrudRepository;

public interface QuestionThemeRepo extends CrudRepository<QuestionTheme, Integer> {
}
