import back from '../assets/imgs/back.svg'
import '../assets/css/background.css'
const Background2 =()=>{
    return <div className="background2">
        <img  src={back} alt="" />
    </div>

}

export default Background2