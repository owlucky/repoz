import top from '../assets/imgs/top.svg'
import '../assets/css/background.css'
const Background =()=>{
    return <div className="background">
        <img src={top} alt="" />
    </div>

}

export default Background